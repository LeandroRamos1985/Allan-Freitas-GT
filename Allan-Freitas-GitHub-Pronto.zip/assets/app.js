(()=>{
const config=window.SITE_CONFIG||{};const lang=document.body.dataset.lang;
window.dataLayer=window.dataLayer||[];
const analyticsAllowed=()=>localStorage.getItem('allan-analytics')==='yes';
function event(name,fields={}){window.dataLayer.push({event:name,language:lang,...fields});if(analyticsAllowed()&&typeof window.gtag==='function')window.gtag('event',name,fields);}
const menu=document.querySelector('.menu'),nav=document.querySelector('#navigation');
function closeMenu(){nav.classList.remove('open');menu.setAttribute('aria-expanded','false');}
menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';nav.classList.toggle('open',open);menu.setAttribute('aria-expanded',String(open));});
nav.addEventListener('click',closeMenu);document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();document.querySelector('.cookies').hidden=true;}});
const video=document.querySelector('#hero-video'),control=document.querySelector('#video-control');
if(video){if(matchMedia('(max-width:560px)').matches)video.poster=video.poster.replace('coastal-sunset-poster.webp','coastal-sunset-poster-mobile.webp');const source=video.querySelector('source');source.src=matchMedia('(max-width:560px)').matches?source.dataset.mobile:source.dataset.desktop;video.load();let manual=false;const reduced=matchMedia('(prefers-reduced-motion:reduce)');
function label(){control.textContent=video.paused?control.dataset.play:control.dataset.pause;control.setAttribute('aria-pressed',String(video.paused));}
video.addEventListener('play',label);video.addEventListener('pause',label);video.addEventListener('error',()=>{control.hidden=true;event('video_error')});
if(reduced.matches){manual=true;video.pause();}else video.play().catch(label);label();
control.addEventListener('click',()=>{if(video.paused){manual=false;video.play().catch(label)}else{manual=true;video.pause()}event('video_control',{action:video.paused?'pause':'play'});});
new IntersectionObserver(entries=>{if(!entries[0].isIntersecting)video.pause();else if(!manual&&!document.hidden)video.play().catch(label)},{threshold:.1}).observe(video);
document.addEventListener('visibilitychange',()=>{if(document.hidden)video.pause();else if(!manual&&video.getBoundingClientRect().bottom>0)video.play().catch(label)});
}
const form=document.querySelector('#lead-form');
document.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{const href=a.getAttribute('href');if(href.startsWith('tel:'))event('phone_click');else if(href.startsWith('mailto:'))event('email_click');else if(a.dataset.goal!==undefined)event('cta_click',{goal:a.dataset.goal});else if(a.target==='_blank')event('external_click',{destination:new URL(a.href).hostname});if(form&&a.dataset.goal!==undefined)form.elements.goal.value=a.dataset.goal;if(form&&a.dataset.region)form.elements.region.value=a.dataset.region;}));
if(form){const query=new URLSearchParams(location.search);if(query.get('region'))form.elements.region.value=query.get('region').slice(0,200);const campaign=Lead.campaign(location.search);const status=form.querySelector('.form-status'),submit=form.querySelector('[type=submit]');
if(!config.leadEndpoint){status.textContent=form.dataset.offline;submit.textContent=lang==='pt-br'?'Ligar para Allan ↗':lang==='es'?'Llamar a Allan ↗':'Call Allan ↗';submit.type='button';submit.addEventListener('click',()=>{event('phone_click');location.href='tel:+14016395163'});}
form.addEventListener('submit',async e=>{e.preventDefault();if(!form.reportValidity())return;if(form.elements.website.value)return;const data=new FormData(form);if(!data.get('name').trim()){form.elements.name.setCustomValidity(lang==='pt-br'?'Informe seu nome.':lang==='es'?'Escribe tu nombre.':'Enter your name.');form.elements.name.reportValidity();return;}if(!config.leadEndpoint){status.textContent=form.dataset.offline;return;}const previous=submit.textContent;submit.disabled=true;submit.textContent=form.dataset.sending;status.textContent='';
try{const payload={name:data.get('name').trim(),email:data.get('email').trim(),phone:data.get('phone').trim(),goal:['buy','sell','invest'][Number(data.get('goal'))],region:data.get('region').trim(),message:data.get('message').trim(),consent:true,language:lang,source:'allan-freitas-website',campaign,consentVersion:'2026-09-15'};await Lead.send(config.leadEndpoint,payload);event('form_submit_success',{goal:payload.goal});location.href='thank-you/';}catch{status.textContent=form.dataset.error;event('form_submit_error');}finally{submit.disabled=false;submit.textContent=previous;}});
form.elements.name.addEventListener('input',()=>form.elements.name.setCustomValidity(''));
}
const banner=document.querySelector('.cookies');
function analytics(){if(!/^G-[A-Z0-9]+$/.test(config.analyticsId||'')||!analyticsAllowed())return;window.gtag=function(){dataLayer.push(arguments)};window.gtag('js',new Date());window.gtag('config',config.analyticsId,{send_page_view:true});const script=document.createElement('script');script.src='https://www.googletagmanager.com/gtag/js?id='+config.analyticsId;script.async=true;document.head.appendChild(script);}
document.querySelectorAll('.privacy-choice').forEach(b=>b.addEventListener('click',()=>{banner.hidden=false;banner.querySelector('button').focus()}));
banner.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{const old=analyticsAllowed();localStorage.setItem('allan-analytics',b.dataset.consent);banner.hidden=true;if(b.dataset.consent==='yes'&&!old)analytics();else if(b.dataset.consent==='no'&&old)location.reload();}));
if(config.analyticsId&&!localStorage.getItem('allan-analytics'))banner.hidden=false;analytics();
})();
