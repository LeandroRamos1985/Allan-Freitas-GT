# Allan Freitas — pacote completo para GitHub Pages

Este ZIP contém o site pronto: index.html, en/, pt-br/, es/, assets/ na raiz. Não requer instalação, npm ou compilação. Vídeo novo local, fontes locais e três idiomas incluídos.

1. Extraia o ZIP. Envie os arquivos e pastas extraídos para a raiz de um repositório GitHub, preservando assets/ e os diretórios de idiomas. Inclua o arquivo oculto .nojekyll.
2. Em Settings → Pages, selecione Deploy from a branch, a branch main e /(root), depois Save.
3. Aguarde o endereço publicado aparecer no GitHub Pages. Abra o endereço público para demonstrar ao cliente.

A configuração segue https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site .

Documentação, licenças, auditoria real dos 72 itens, ferramentas e testes estão em _entrega/. Essa pasta pode ser mantida apenas localmente; para publicar o site, envie somente os arquivos do site na raiz e as pastas en/, pt-br/, es/ e assets/.

Pronto para demonstração visual. Formulários mostram orientação honesta enquanto não houver gateway real; telefone e e-mail estão ativos. CRM/LeadPilot e analytics ainda precisam das configurações reais. A prévia permanece noindex para não indexar a demonstração como domínio oficial.
