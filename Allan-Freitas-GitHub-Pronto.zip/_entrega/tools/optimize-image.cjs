// Optional: npm install, then node tools/optimize-image.cjs input.png output.webp
// Compression and proportional size limit only. Portrait framing stays in CSS.
const sharp=require('sharp');
const [input,output]=process.argv.slice(2);
if(!input||!output)throw Error('Supply input and output paths');
sharp(input).resize({width:1600,withoutEnlargement:true}).webp({quality:88,effort:6}).toFile(output).then(info=>console.log(info));
