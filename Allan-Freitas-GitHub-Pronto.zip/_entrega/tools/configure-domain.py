"""Run against a copy: python tools/configure-domain.py https://verified-domain.example[/repository]
Never use an unconfirmed domain. This changes the preview into indexable production output.
"""
from pathlib import Path
from urllib.parse import urlparse
import sys,re,json,html
root=Path(__file__).resolve().parents[1]/'site'
origin=sys.argv[1].rstrip('/') if len(sys.argv)>1 else ''
u=urlparse(origin)
if u.scheme!='https' or not u.hostname or u.query or u.fragment or u.username or u.password:
 raise SystemExit('Supply the verified HTTPS origin, optionally with repository path.')
pages=[]
for f in root.rglob('*.html'):
 rel=f.relative_to(root).as_posix()
 if rel=='index.html' or rel.endswith('404.html'):continue
 route=rel.removesuffix('index.html')
 url=origin+'/'+route
 s=f.read_text(encoding='utf-8')
 s=re.sub(r'<link rel="(?:canonical|alternate)"[^>]*>','',s)
 s=re.sub(r'<script type="application/ld\+json">.*?</script>','',s,flags=re.S)
 s=re.sub(r'<meta property="og:(?:image|url)"[^>]*>','',s)
 s=s.replace('content="noindex,follow"','content="noindex,follow"' if '/thank-you/' in url else 'content="index,follow"')
 additions=f'<link rel="canonical" href="{html.escape(url,quote=True)}"><meta property="og:url" content="{html.escape(url,quote=True)}"><meta property="og:image" content="{html.escape(origin,quote=True)}/assets/social.jpg">'
 parts=route.split('/');suffix='/'.join(parts[1:])
 for code,lang in [('en','en'),('pt-br','pt-BR'),('es','es')]:additions+=f'<link rel="alternate" hreflang="{lang}" href="{html.escape(origin,quote=True)}/{code}/{suffix}">'
 additions+=f'<link rel="alternate" hreflang="x-default" href="{html.escape(origin,quote=True)}/en/{suffix}">'
 schema={'@context':'https://schema.org','@type':'RealEstateAgent','name':'Allan Freitas','url':origin+'/en/','telephone':'+14016395163','email':'allanfreitasrealtor@gmail.com','image':origin+'/assets/allan.webp','parentOrganization':{'@type':'Organization','name':'HomeSmart First Class Realty'},'address':{'@type':'PostalAddress','streetAddress':'670 Depot Street, Suite 1','addressLocality':'North Easton','addressRegion':'MA','postalCode':'02356','addressCountry':'US'},'areaServed':['Fall River','Somerset','Swansea','Westport','Tiverton','Portsmouth'],'knowsLanguage':['English','Portuguese','Spanish']}
 # JSON-LD is structured data, not an executable inline script.
 if route in ['en/','pt-br/','es/']:
  depth=len(parts)-1
  additions+='<script type="application/ld+json">'+json.dumps(schema).replace('<','\\u003c')+'</script>'
 s=s.replace('</head>',additions+'</head>');f.write_text(s,encoding='utf-8')
 if '/thank-you/' not in url:pages.append(url)
ns='http://www.sitemaps.org/schemas/sitemap/0.9'
(root/'sitemap.xml').write_text(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="{ns}">'+''.join('<url><loc>'+html.escape(url)+'</loc></url>' for url in pages)+'</urlset>',encoding='utf-8')
(root/'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: '+origin+'/sitemap.xml\n',encoding='utf-8')
(root/'assets/config.js').write_text(re.sub(r"siteUrl:(?:''|\"[^\"]*\")",'siteUrl:'+json.dumps(origin),(root/'assets/config.js').read_text()),encoding='utf-8')
print('Configured',len(pages),'indexable pages and sitemap. Review brokerage disclosures, CRM and HTTPS before release.')
