from pathlib import Path
from html.parser import HTMLParser
from urllib.request import Request,urlopen
from urllib.parse import urlsplit,urlunsplit
from concurrent.futures import ThreadPoolExecutor
import json,time
class Links(HTMLParser):
 def handle_starttag(self,tag,attrs):
  if tag=='a':
   for key,value in attrs:
    if key=='href' and value.startswith('https:'):
     p=urlsplit(value);urls.add(urlunsplit((p.scheme,p.netloc,p.path,p.query,'')))
urls=set();p=Links()
for f in Path('site').rglob('*.html'):p.feed(f.read_text(encoding='utf-8'))
refs=['https://erikabarretto.com/','https://leandroramos1985.github.io/laiane-neto-realtor/','https://leandroramos1985.github.io/Marilene-Araujo-Atualizado/','https://site-imobiliaria-six.vercel.app/','https://leandroramos1985.github.io/ANA-ROQUE-ATUAL-2357/','https://leandroramos1985.github.io/dr-realty-CL/','https://www.awwwards.com/','https://21st.dev/','https://www.aura.build/']
def check(url):
 try:
  with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=15) as r:
   content=r.read(250000).decode('utf-8','replace')
   if url in refs:
    dest=Path('work/references');dest.mkdir(exist_ok=True);(dest/(str(refs.index(url))+'.html')).write_text(content,encoding='utf-8')
   return dict(url=url,status=r.status,finalUrl=r.url,bytesSampled=len(content),purpose='reference' if url in refs else 'site link')
 except Exception as e:return dict(url=url,error=str(e),purpose='reference' if url in refs else 'site link')
with ThreadPoolExecutor(max_workers=6) as ex:results=list(ex.map(check,sorted(urls|set(refs))))
Path('evidence/external-links.json').write_text(json.dumps({'date':'2026-09-15','results':results,'limitations':'HTTP reachability does not validate mailbox delivery, phone call or protected platform content.'},indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
