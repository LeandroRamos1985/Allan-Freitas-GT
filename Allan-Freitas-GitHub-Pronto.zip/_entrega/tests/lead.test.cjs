const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const scope={globalThis:{},fetch,URL,URLSearchParams,AbortController,setTimeout,clearTimeout};
vm.runInNewContext(fs.readFileSync('site/assets/lead.js','utf8'),scope);
const api=scope.globalThis.Lead;
test('missing integration cannot become a successful submission',async()=>{await assert.rejects(api.send('',{}),/unconfigured/)});
test('non-HTTPS remote endpoint is rejected',async()=>{await assert.rejects(api.send('http://example.com/lead',{}),/https/)});
test('tracking strips personal information and retains allowed campaign fields',()=>{assert.deepEqual(JSON.parse(JSON.stringify(api.campaign('?utm_source=google&email=private&gclid=123'))),{utm_source:'google',gclid:'123'})});
test('HTTP error does not report delivery',async()=>{await assert.rejects(api.send('https://example.com/lead',{},async()=>({ok:false,status:500,json:async()=>({success:true})})),/delivery/)});
test('ambiguous server response does not report delivery',async()=>{await assert.rejects(api.send('https://example.com/lead',{},async()=>({ok:true,json:async()=>({})})),/confirmation/)});
test('explicit server confirmation completes delivery',async()=>{assert.equal(await api.send('https://example.com/lead',{},async()=>({ok:true,json:async()=>({success:true})})),true)});


