# Briefing padrão para sites — atualizado em 15/09/2026

Aplica-se ao Allan Freitas e aos próximos projetos de sites neste workspace. Requisitos específicos de cada cliente e pedidos posteriores do usuário prevalecem.

Vídeo premium em movimento na primeira dobra; conteúdo real em inglês, português brasileiro e espanhol; luxo, qualidade, elegância e sofisticação; auditoria dos 72 critérios antes, durante e na finalização. Avisar antes da auditoria final e testar em navegador real desktop/mobile. Não fabricar resultados, dados, avaliações ou aprovação de serviços não testados.

## Referências obrigatórias

- https://erikarealtorflorida.com/
- https://erikabarretto.com/
- https://leandroramos1985.github.io/laiane-neto-realtor/
- https://leandroramos1985.github.io/Marilene-Araujo-Atualizado/
- https://site-imobiliaria-six.vercel.app/
- https://leandroramos1985.github.io/ANA-ROQUE-ATUAL-2357/
- https://leandroramos1985.github.io/dr-realty-CL/
- https://www.awwwards.com/
- https://21st.dev/
- https://www.aura.build/

## Mídia distinta: etapa obrigatória antes de escolher

Inventariar mídia das referências, projetos anteriores e concorrentes do nicho. Para cada candidato, pesquisar na internet URL/ID/título/autor e termos do segmento; procurar versões reeditadas e hospedadas em outros domínios. Usar busca reversa de fotos/frames quando disponível e comparar visualmente cenas, imóveis, fachadas, enquadramento, movimento, iluminação e composição. Rejeitar vídeos/fotos iguais ou visualmente semelhantes aos encontrados em outros sites do mesmo nicho. Recorte, filtro, espelhamento e resolução diferente não contornam a regra.

Registrar fonte, licença, data, consultas, sites comparados e decisão para cada ativo. Não reutilizar mídia de projetos anteriores por conveniência. Não interpretar ausência de resultados como garantia de exclusividade mundial. Quando for indispensável garantir exclusividade, priorizar produção original autorizada ou licença exclusiva documentada. Retratos e imóveis reais do cliente precisam preservar identidade e autorização; não trocar por pessoas/imóveis fictícios. Ao adicionar esta regra a projeto existente, identificar mídia conflitante, bloquear aprovação e substituir/retestar antes de publicar.

## 72 critérios

Cada item deve receber Aprovado, Atenção, Falhou ou Não aplicável, com evidência real. READY FOR PRODUCTION exige ausência de falhas críticas e cumprimento das exigências específicas do briefing.

1. **CTA principal na primeira dobra** — O visitante deve entender rapidamente qual é a principal ação esperada.
2. **CTAs claros e consistentes** — Os principais caminhos de conversão devem utilizar linguagem clara e coerente.
3. **CTA fixo no mobile, quando adequado** — Implementar CTA fixo quando fizer sentido para o projeto.
4. **Promessa/expectativa de tempo de resposta, quando aplicável** — Informar prazo realista de contato quando houver esse compromisso.
5. **Página de obrigado após conversão** — Formulários importantes devem possuir experiência adequada pós-envio.
6. **Formulários com validação e estados de erro/sucesso** — Nenhum formulário deve parecer enviado quando ocorreu erro.
7. **Links e URLs amigáveis/personalizados** — Evitar URLs confusas e caminhos desnecessariamente complexos.
8. **Seção de cases/resultados quando houver material autorizado** — Nunca inventar cases.
9. **Avaliações reais e verificáveis** — Nunca fabricar avaliações por IA.
10. **Mapas, endereço e rotas** — Informações de localização devem estar corretas e utilizáveis.
11. **Responsividade completa para celular, tablet e desktop** — O site precisa funcionar integralmente nas principais resoluções.
12. **Meta title único por página** — Cada página indexável deve possuir título adequado.
13. **Meta description única por página** — Produzir descrições específicas, naturais e orientadas à intenção de busca.
14. **H1 único e hierarquia correta de H2/H3** — Manter estrutura semântica de conteúdo.
15. **Títulos e conteúdo sem duplicações desnecessárias** — Evitar conteúdo repetido que reduza qualidade e SEO.
16. **Alt text contextual nas imagens** — Os textos alternativos devem descrever contexto e função das imagens quando necessário.
17. **Breadcrumbs quando fizerem sentido** — Especialmente importantes em áreas como bairros, listagens e conteúdo.
18. **FAQ + dados estruturados de FAQ somente quando aplicáveis** — Não adicionar FAQ Schema artificialmente.
19. **URLs amigáveis** — Utilizar slugs limpos, legíveis e consistentes.
20. **Canonical tags** — Configurar canonicals corretamente.
21. **robots.txt** — Criar e revisar regras de rastreamento.
22. **sitemap.xml** — Manter sitemap atualizado.
23. **Página 404 personalizada** — Criar experiência útil mesmo para URLs inexistentes.
24. **Favicon** — Implementar favicon adequado à marca.
25. **Open Graph** — Configurar títulos, descrições e imagem de compartilhamento.
26. **Imagem adequada para compartilhamento social** — Criar imagem social consistente com a identidade visual.
27. **Dados estruturados LocalBusiness ou tipo mais específico aplicável** — Aplicar Schema.org corretamente ao negócio.
28. **Google Search Console configurável após domínio/verificação** — Preparar o projeto para configuração e validação.
29. **Verificação automática de links quebrados** — Links internos e externos devem ser testados.
30. **Indexabilidade das páginas verificada** — Confirmar quais páginas devem e não devem aparecer nos buscadores.
31. **Compressão e otimização automática de imagens** — Nenhuma imagem deve ser desnecessariamente pesada.
32. **Formatos modernos de imagem quando adequados** — Usar WebP, AVIF ou formato apropriado quando houver benefício.
33. **Lazy loading** — Aplicar carregamento tardio onde fizer sentido.
34. **Teste de PageSpeed/Lighthouse** — Auditar páginas importantes.
35. **Core Web Vitals** — Monitorar e otimizar LCP, CLS e INP.
36. **Otimização de carregamento de fontes, CSS e JavaScript** — Reduzir recursos bloqueantes e peso desnecessário.
37. **HTTPS/SSL** — Produção deve funcionar integralmente em HTTPS.
38. **Headers e configurações básicas de segurança** — Aplicar boas práticas de segurança compatíveis com a infraestrutura.
39. **Proteção anti-spam/bot nos formulários** — Evitar abuso de formulários.
40. **Tratamento seguro dos dados enviados** — Nenhuma informação do usuário deve ser exposta ou tratada de forma insegura.
41. **Política de Privacidade** — Disponibilizar documento adequado ao uso real do site.
42. **Cookies/consentimento quando juridicamente necessário** — Implementar consentimento conforme tecnologias utilizadas e requisitos aplicáveis.
43. **Dados empresariais/profissionais no rodapé** — Exibir informações reais e adequadas da empresa.
44. **Google Analytics ou solução equivalente** — Configurar mensuração adequada.
45. **Eventos de conversão configurados** — Definir e medir ações importantes.
46. **Cliques em WhatsApp monitoráveis** — Quando WhatsApp fizer parte do site.
47. **Envios de formulário monitoráveis** — Registrar conversões reais.
48. **Origem/campanha do lead preservada quando possível** — Preservar parâmetros como UTM quando aplicável.
49. **Integração com CRM do LeadPilot** — Preparar lead e informações de origem para entrada no CRM.
50. **Teste real dos eventos antes da publicação** — Não considerar tracking pronto apenas porque o código foi instalado.
51. **Logo e identidade visual** — Aplicar a marca de forma consistente.
52. **Informações reais do negócio** — Todo conteúdo factual deve representar corretamente a empresa.
53. **Telefone/WhatsApp conferidos** — Testar números e links.
54. **Endereço e horários conferidos** — Confirmar informações antes da publicação.
55. **Serviços/especialidades conferidos** — Não anunciar serviços inexistentes.
56. **Fotos reais autorizadas** — Utilizar fotos próprias, licenciadas ou autorizadas.
57. **Informações da equipe/profissionais conferidas** — Nomes, cargos, fotos e informações devem ser corretos.
58. **Avaliações reais sem fabricação por IA** — Proibido gerar depoimentos falsos.
59. **Conteúdo adaptado ao segmento e localização** — O texto deve parecer feito especificamente para o negócio e sua região.
60. **Revisão de informações sensíveis ou regulamentadas** — Conteúdo sujeito a requisitos legais ou profissionais deve ser revisado.
61. **Teste desktop** — Testar páginas e funcionalidades em desktop.
62. **Teste mobile** — Testar páginas e funcionalidades em smartphones.
63. **Teste de todos os formulários** — Submeter cada formulário e confirmar comportamento completo.
64. **Teste de todos os CTAs** — Cada CTA deve levar ao destino correto.
65. **Teste dos links externos** — Validar links e comportamento.
66. **Teste de WhatsApp, telefone e e-mail** — Todos os canais de contato devem funcionar.
67. **Auditoria SEO** — Executar revisão SEO final.
68. **Auditoria de acessibilidade básica** — Validar contraste, labels, navegação, foco, estrutura e principais requisitos.
69. **Auditoria de performance** — Verificar carregamento, peso, Lighthouse e gargalos.
70. **Auditoria de segurança** — Revisar configurações e riscos básicos antes da publicação.
71. **Verificação de domínio/SSL** — Confirmar domínio final, redirecionamentos e certificado SSL.
72. **Site Quality Score final** — Gerar pontuação final com itens aprovados, em atenção, falharam, não aplicáveis, correções realizadas, pendências e bloqueadores de publicação.

## Entrega obrigatória: demonstração pública no GitHub

Para este e os próximos projetos de sites, entregar ZIP completo pronto para GitHub Pages e link público de demonstração para apresentação ao cliente. Não concluir a entrega apenas com ZIP ou localhost. Publicar no GitHub Pages quando houver acesso autorizado à conta, testar o endereço público e informar o link confirmado. Se faltar autenticação, preparar o pacote completo e pedir somente o acesso necessário, sem inventar URL publicada. Distinguir demonstração de integrações reais de atendimento/analytics; não fabricar sucesso de envio.
